/* global React, Icon, BENEFS, EMENDAS, fmtBRL */
const { useState: useStateS1, useMemo: useMemoS1 } = React;

function StepSelection({ state, setState, onNext }) {
  const { benef, emenda } = state;
  const [benefQ, setBenefQ] = useStateS1('');
  const [emendaQ, setEmendaQ] = useStateS1('');

  const benefsFiltered = useMemoS1(() => {
    const q = benefQ.trim().toLowerCase();
    if (!q) return BENEFS;
    return BENEFS.filter((b) => b.name.toLowerCase().includes(q) || b.cnpj.includes(q.replace(/\D/g, '')));
  }, [benefQ]);

  const emendasFiltered = useMemoS1(() => {
    const q = emendaQ.trim().toLowerCase();
    if (!q) return EMENDAS;
    return EMENDAS.filter((e) =>
      e.objeto.toLowerCase().includes(q) ||
      e.parlamentar.toLowerCase().includes(q) ||
      e.id.includes(q.replace(/\D/g, ''))
    );
  }, [emendaQ]);

  return (
    <div className="main">
      <h1>Prepare um novo plano de trabalho</h1>
      <p className="lede">
        Selecione o beneficiário, a emenda parlamentar e, se quiser, adicione contexto para a IA. O sistema pré-preencherá o plano com base na API do TransfereGov, no histórico de planos aprovados e em IA.
      </p>

      {/* 01 Beneficiário */}
      <div className="card">
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">01</span> Beneficiário</h2>
            <p className="hint">Ente federado que receberá o recurso e será responsável pela execução.</p>
          </div>
          <span className="count">
            {benef ? <><b style={{ color: 'var(--ink-1)' }}>{benef.name}</b></> : `${BENEFS.length} entes`}
          </span>
        </div>

        <div className="search-input">
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <circle cx="7" cy="7" r="4.5"/><path d="M13.5 13.5L10.5 10.5"/>
          </svg>
          <input
            type="text"
            placeholder="Buscar por nome ou CNPJ…"
            value={benefQ}
            onChange={(e) => setBenefQ(e.target.value)}
          />
          {benefQ && <button className="clear" onClick={() => setBenefQ('')}>✕</button>}
        </div>

        <div className="scroll-list">
          {benefsFiltered.length === 0 && (
            <div className="empty">Nenhum beneficiário encontrado para "{benefQ}".</div>
          )}
          {benefsFiltered.map((b) => (
            <button
              key={b.cnpj}
              className={'benef-row' + (benef?.cnpj === b.cnpj ? ' selected' : '')}
              onClick={() => setState((s) => ({ ...s, benef: b }))}
            >
              <div className="radio" />
              <div className="benef-body">
                <div className="benef-name">{b.name}</div>
                <div className="benef-cnpj">{b.kind} · CNPJ {b.cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5')}</div>
              </div>
            </button>
          ))}
        </div>
        <div className="scroll-hint">Mostrando {benefsFiltered.length} de {BENEFS.length} · role para ver mais</div>
      </div>

      {/* 02 Emenda */}
      <div className="card" style={{ opacity: benef ? 1 : 0.45, pointerEvents: benef ? 'auto' : 'none' }}>
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">02</span> Emenda parlamentar</h2>
            <p className="hint">{benef ? `${EMENDAS.length} emendas disponíveis para ${benef.name}.` : 'Selecione um beneficiário primeiro.'}</p>
          </div>
          {emenda && <span className="count"><b style={{ color: 'var(--ink-1)' }}>{fmtBRL(emenda.valor)}</b></span>}
        </div>

        <div className="search-input">
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
            <circle cx="7" cy="7" r="4.5"/><path d="M13.5 13.5L10.5 10.5"/>
          </svg>
          <input
            type="text"
            placeholder="Buscar por objeto, parlamentar ou número…"
            value={emendaQ}
            onChange={(e) => setEmendaQ(e.target.value)}
          />
          {emendaQ && <button className="clear" onClick={() => setEmendaQ('')}>✕</button>}
        </div>

        <div className="scroll-list tall">
          {emendasFiltered.length === 0 && (
            <div className="empty">Nenhuma emenda encontrada.</div>
          )}
          {emendasFiltered.map((e) => (
            <div
              key={e.id}
              className={'emenda-row' + (emenda?.id === e.id ? ' selected' : '')}
              onClick={() => setState((s) => ({ ...s, emenda: e }))}
            >
              <div className="radio" />
              <div className="emenda-body">
                <div className="emenda-objeto">{e.objeto}</div>
                <div className="emenda-sub">{e.id} · {e.parlamentar} · {e.funcional}</div>
              </div>
              <div className="emenda-amount">
                {fmtBRL(e.valor)}
                <span className="pill">valor total</span>
              </div>
            </div>
          ))}
        </div>
        <div className="scroll-hint">Mostrando {emendasFiltered.length} de {EMENDAS.length}</div>
      </div>

      {/* 03 Contexto */}
      <div className="card" style={{ opacity: (benef && emenda) ? 1 : 0.45, pointerEvents: (benef && emenda) ? 'auto' : 'none' }}>
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">03</span> Contexto adicional <span className="optional">opcional</span></h2>
            <p className="hint">Detalhes fornecidos pelo parlamentar ou pela secretaria sobre como o projeto será executado. Quanto mais contexto, melhor o preenchimento das metas e do detalhamento do objeto (2.5, 2.6, 2.7).</p>
          </div>
        </div>
        <div className="field" data-src="manual">
          <textarea
            placeholder={"Ex.: serão realizadas feiras de negócios em 4 municípios; público-alvo são mulheres em situação de vulnerabilidade; o projeto inclui capacitação de 200 artesãos…\n\nSe vazio, o sistema usará apenas os dados da API e do histórico de planos aprovados."}
            value={state.contexto || ''}
            onChange={(e) => setState((s) => ({ ...s, contexto: e.target.value }))}
            style={{ minHeight: 110 }}
          />
          <div className="help">A IA usa este texto para adaptar o detalhamento do objeto e gerar metas mais precisas.</div>
        </div>
      </div>

      <div className="actionbar">
        <div className="summary">
          {benef && emenda ? (
            <>Pronto para gerar. <b>{benef.name}</b> · {fmtBRL(emenda.valor)}{state.contexto ? ' · com contexto adicional' : ''}</>
          ) : benef ? (
            <>Selecione uma emenda para continuar.</>
          ) : (
            <>Selecione o beneficiário e a emenda.</>
          )}
        </div>
        <button className="btn ghost" disabled>
          <Icon.arrowL /> Voltar
        </button>
        <button className="btn primary" disabled={!benef || !emenda} onClick={onNext}>
          <Icon.sparkle /> Gerar plano pré-preenchido
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { StepSelection });

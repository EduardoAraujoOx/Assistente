/* global React */
const { useState, useEffect, useRef } = React;

/* ===== Icons ===== */
const Icon = {
  sparkle: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M8 2v4M8 10v4M2 8h4M10 8h4M4 4l2 2M10 10l2 2M12 4l-2 2M6 10l-2 2"/>
    </svg>
  ),
  copy: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <rect x="5" y="5" width="8" height="8" rx="1.5"/><path d="M3 10V4a1 1 0 0 1 1-1h6"/>
    </svg>
  ),
  refresh: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M13.5 4.5A5.5 5.5 0 1 0 14 9"/><path d="M14 2v3h-3"/>
    </svg>
  ),
  check: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 8l3.5 3.5L13 5"/>
    </svg>
  ),
  arrowR: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 8h10M9 4l4 4-4 4"/>
    </svg>
  ),
  arrowL: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M13 8H3M7 4L3 8l4 4"/>
    </svg>
  ),
  info: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}>
      <circle cx="8" cy="8" r="6.5"/><path d="M8 7v4M8 5v.01" strokeLinecap="round"/>
    </svg>
  ),
  edit: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M11 2.5l2.5 2.5L6 12.5 3 13l.5-3z"/>
    </svg>
  ),
  more: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor" {...p}>
      <circle cx="3" cy="8" r="1.3"/><circle cx="8" cy="8" r="1.3"/><circle cx="13" cy="8" r="1.3"/>
    </svg>
  ),
  send: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M14 2L7 9M14 2L9.5 14 7 9 2 6.5z"/>
    </svg>
  ),
  external: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M10 3h3v3M13 3l-6 6M12 10v2.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5H6"/>
    </svg>
  ),
};

/* ===== Sample data ===== */
const BENEFS = [
  { cnpj: '27080530000143', name: 'Estado do Espírito Santo', kind: 'Governo do Estado' },
  { cnpj: '27165120000173', name: 'Prefeitura de Vitória', kind: 'Município' },
  { cnpj: '27161118000191', name: 'Prefeitura de Vila Velha', kind: 'Município' },
  { cnpj: '27153373000180', name: 'Prefeitura de Serra', kind: 'Município' },
  { cnpj: '27167764000180', name: 'Prefeitura de Cariacica', kind: 'Município' },
  { cnpj: '27169557000152', name: 'Prefeitura de Guarapari', kind: 'Município' },
  { cnpj: '27163919000163', name: 'Prefeitura de Linhares', kind: 'Município' },
  { cnpj: '27142690000141', name: 'Prefeitura de Cachoeiro de Itapemirim', kind: 'Município' },
  { cnpj: '27174192000130', name: 'Prefeitura de São Mateus', kind: 'Município' },
  { cnpj: '27174028000144', name: 'Prefeitura de Colatina', kind: 'Município' },
  { cnpj: '27174580000106', name: 'Prefeitura de Aracruz', kind: 'Município' },
  { cnpj: '27142692000140', name: 'Prefeitura de Alegre', kind: 'Município' },
  { cnpj: '27174600000107', name: 'Prefeitura de Anchieta', kind: 'Município' },
  { cnpj: '27174320000108', name: 'Prefeitura de Baixo Guandu', kind: 'Município' },
  { cnpj: '27174109000109', name: 'Prefeitura de Barra de São Francisco', kind: 'Município' },
  { cnpj: '27174201000110', name: 'Prefeitura de Castelo', kind: 'Município' },
  { cnpj: '27174302000111', name: 'Prefeitura de Conceição da Barra', kind: 'Município' },
  { cnpj: '27174403000112', name: 'Prefeitura de Domingos Martins', kind: 'Município' },
  { cnpj: '27174504000113', name: 'Prefeitura de Ecoporanga', kind: 'Município' },
  { cnpj: '27174605000114', name: 'Prefeitura de Fundão', kind: 'Município' },
  { cnpj: '27174706000115', name: 'Prefeitura de Iúna', kind: 'Município' },
  { cnpj: '27174807000116', name: 'Prefeitura de Jaguaré', kind: 'Município' },
  { cnpj: '27174908000117', name: 'Prefeitura de Marataízes', kind: 'Município' },
  { cnpj: '27175009000118', name: 'Prefeitura de Mimoso do Sul', kind: 'Município' },
  { cnpj: '27175100000119', name: 'Prefeitura de Nova Venécia', kind: 'Município' },
  { cnpj: '27175201000120', name: 'Prefeitura de Piúma', kind: 'Município' },
  { cnpj: '27175302000121', name: 'Prefeitura de Presidente Kennedy', kind: 'Município' },
  { cnpj: '27175403000122', name: 'Prefeitura de Rio Bananal', kind: 'Município' },
  { cnpj: '27175504000123', name: 'Prefeitura de Santa Maria de Jetibá', kind: 'Município' },
  { cnpj: '27175605000124', name: 'Prefeitura de Santa Teresa', kind: 'Município' },
  { cnpj: '27175706000125', name: 'Prefeitura de São Gabriel da Palha', kind: 'Município' },
  { cnpj: '27175807000126', name: 'Prefeitura de Venda Nova do Imigrante', kind: 'Município' },
  { cnpj: '27175908000127', name: 'Prefeitura de Viana', kind: 'Município' },
  { cnpj: '27176009000128', name: 'Prefeitura de Afonso Cláudio', kind: 'Município' },
  { cnpj: '27176100000129', name: 'Prefeitura de Alfredo Chaves', kind: 'Município' },
];

const EMENDAS = [
  { id: '202400012345', parlamentar: 'Dep. Maria F. Santos', objeto: 'Apoio à capacitação técnica no meio rural, pesqueiro e agrícola', valor: 1_200_000, funcional: '20.608.0038.2244' },
  { id: '202400019876', parlamentar: 'Sen. Carlos Ribeiro', objeto: 'Aquisição de equipamentos de saúde para unidades básicas', valor: 850_000, funcional: '10.302.0015.1122' },
  { id: '202400024431', parlamentar: 'Dep. João Pereira', objeto: 'Infraestrutura viária urbana e rural', valor: 2_500_000, funcional: '15.451.0042.3311' },
  { id: '202400027765', parlamentar: 'Dep. Ana Beatriz', objeto: 'Fomento a programas educacionais e culturais', valor: 620_000, funcional: '12.361.0061.4408' },
  { id: '202400031902', parlamentar: 'Sen. Roberto Mendes', objeto: 'Ampliação de creches municipais e material escolar', valor: 980_000, funcional: '12.365.0073.5512' },
  { id: '202400034118', parlamentar: 'Dep. Luciana Ferreira', objeto: 'Fortalecimento da atenção primária e compra de medicamentos', valor: 1_450_000, funcional: '10.301.0017.2020' },
  { id: '202400038876', parlamentar: 'Dep. Paulo Henrique', objeto: 'Apoio a pequenas obras de saneamento básico', valor: 1_800_000, funcional: '17.512.0089.1905' },
  { id: '202400041203', parlamentar: 'Dep. Regina Oliveira', objeto: 'Programa de segurança alimentar e nutricional', valor: 540_000, funcional: '08.306.0023.4412' },
  { id: '202400045670', parlamentar: 'Sen. André Castro', objeto: 'Aquisição de veículos para o serviço social municipal', valor: 720_000, funcional: '08.244.0029.2233' },
  { id: '202400049011', parlamentar: 'Dep. Fernanda Lopes', objeto: 'Revitalização de praças e espaços públicos de convivência', valor: 430_000, funcional: '15.452.0051.1177' },
  { id: '202400052834', parlamentar: 'Dep. Ricardo Almeida', objeto: 'Apoio ao esporte amador e construção de quadras', valor: 680_000, funcional: '27.812.0034.2255' },
  { id: '202400056709', parlamentar: 'Sen. Beatriz Campos', objeto: 'Programa de inclusão digital em escolas públicas', valor: 390_000, funcional: '12.363.0065.6680' },
];

const fmtBRL = (n) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });

Object.assign(window, { Icon, BENEFS, EMENDAS, fmtBRL });

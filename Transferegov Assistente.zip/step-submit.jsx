/* global React, Icon, fmtBRL */
const { useState: useStateS3 } = React;

const ALL_FIELDS = [
  { k: '1.1', v: 'Sim — recursos indicados no orçamento próprio', src: 'Declaração' },
  { k: '1.2', v: '31.101.20.608.0038.2244 — Apoio a capacitação técnica no meio rural, pesqueiro e agrícola.', src: 'Histórico · exercício anterior' },
  { k: '1.3', v: 'Sim — recursos não serão usados para despesa de pessoal / serviço da dívida', src: 'Declaração' },
  { k: '1.4', v: '36 meses', src: 'Histórico · média de planos aprovados' },
  { k: '2.1', v: 'Sim', src: 'Declaração' },
  { k: '2.2', v: 'SECRETARIA DE ESTADO DA AGRICULTURA, ABASTECIMENTO, AQUICULTURA E PESCA (27.080.555/0001-47)', src: 'Histórico · executor frequente' },
  { k: '2.3', v: null, src: 'API TransfereGov · SIOP', useObjeto: true },
  { k: '2.4', v: 'obj. 260 — Capacitação técnica (padrão SIOP)', src: 'API TransfereGov · SIOP' },
  { k: '2.5', v: 'O projeto prevê a capacitação técnica de aproximadamente 450 produtores rurais, pescadores artesanais e aquicultores do Espírito Santo, por meio de oficinas presenciais, visitas técnicas e material didático impresso. As atividades serão conduzidas em parceria com o Incaper nas regiões Norte, Sul e Central do estado.', src: 'Histórico + IA' },
  { k: '2.6', v: 'Fortalecer a assistência técnica e extensão rural; ampliar o acesso dos produtores familiares a práticas sustentáveis; promover o desenvolvimento da aquicultura e pesca artesanal capixaba.', src: 'Gerado por IA' },
  { k: '2.7', v: 'Realizar 24 oficinas de capacitação técnica, alcançando pelo menos 450 beneficiários diretos, com material didático e certificação, ao longo de 36 meses.', src: 'Gerado por IA' },
  { k: '2.8', v: 'Sim — conta específica do executor', src: 'Declaração' },
  { k: '2.9', v: '001 — Banco do Brasil', src: 'Histórico' },
  { k: '2.10', v: '3823-0', src: 'Histórico' },
  { k: '2.11', v: 'Conselho Estadual de Desenvolvimento Rural Sustentável (CEDRS)', src: 'Histórico' },
];

function StepSubmit({ state, onBack, onRestart }) {
  const { benef, emenda } = state;
  const [email, setEmail] = useStateS3('');
  const [nome, setNome] = useStateS3('');
  const [copied, setCopied] = useStateS3(false);

  const copyAll = () => {
    const text = ALL_FIELDS.map(f => `${f.k}\n${f.useObjeto ? emenda?.objeto : f.v}\n`).join('\n');
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="main">
      <div className="done-hero">
        <div className="check">
          <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12.5L9.5 18 20 7"/></svg>
        </div>
        <h2>Plano pronto para envio</h2>
        <p>Abra o TransfereGov e copie cada campo para o formulário oficial. Você também pode receber o resumo completo por e-mail.</p>
      </div>

      <div className="handoff-card">
        <div className="handoff-info">
          <div className="handoff-title">Preenchimento no TransfereGov</div>
          <div className="handoff-sub">O sistema oficial não aceita pré-preenchimento via URL. Abra o plano em uma nova aba e cole os campos manualmente — use "Copiar tudo" ou o botão de copiar ao lado de cada campo abaixo.</div>
        </div>
        <div className="handoff-actions">
          <button className="btn ghost" onClick={copyAll}>
            {copied ? <><Icon.check /> Copiado</> : <><Icon.copy /> Copiar tudo</>}
          </button>
          <a className="btn brand" href="https://especiais.transferegov.sistema.gov.br/" target="_blank" rel="noreferrer">
            <Icon.external /> Abrir TransfereGov
          </a>
        </div>
      </div>

      <div className="card">
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">—</span> Resumo do plano</h2>
            <p className="hint">{benef?.name} · Emenda {emenda?.id} · {ALL_FIELDS.length} campos prontos</p>
          </div>
        </div>

        <div className="summary-list">
          {ALL_FIELDS.map((f) => (
            <div key={f.k} className="row">
              <div className="k">{f.k}</div>
              <div className="v">
                {f.useObjeto ? emenda?.objeto : f.v}
                <div className="meta">{f.src}</div>
              </div>
              <button className="row-copy" title="Copiar campo" onClick={() => navigator.clipboard?.writeText(f.useObjeto ? (emenda?.objeto || '') : f.v)}>
                <Icon.copy />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">@</span> Resumo por e-mail</h2>
            <p className="hint">Opcional. Útil para guardar o plano no seu e-mail antes de colar no TransfereGov.</p>
          </div>
        </div>

        <div style={{ display: 'grid', gap: 4 }}>
          <div className="field" data-src="manual">
            <div className="label-row"><span className="label">Seu nome</span></div>
            <input type="text" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex.: João da Silva" />
          </div>
          <div className="field" data-src="manual">
            <div className="label-row"><span className="label">Seu e-mail<span className="req">*</span></span></div>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@sefaz.es.gov.br" />
          </div>
        </div>
      </div>

      <div className="actionbar">
        <div className="summary">
          Após enviar, o plano é armazenado apenas localmente para sua sessão.
        </div>
        <button className="btn ghost" onClick={onBack}><Icon.arrowL /> Voltar</button>
        <button className="btn ghost" onClick={onRestart}>Novo plano</button>
        <button className="btn primary" disabled={!email}>
          <Icon.send /> Enviar resumo
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { StepSubmit });

/* global React, Icon */
const { useState: useStateS2 } = React;

function Field({ num, label, required, src, help, children, focusedId, setFocusedId, id, actions = ['ai', 'copy', 'refresh'] }) {
  const isFocused = focusedId === id;
  const srcLabels = { api: 'API', hist: 'Histórico', ai: 'IA' };

  return (
    <div
      className={'field' + (isFocused ? ' focused' : '')}
      data-src={src}
      onFocus={() => setFocusedId(id)}
      onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setFocusedId(null); }}
      tabIndex={-1}
    >
      <div className="label-row">
        <span className="label">
          <span className="num">{num}</span>{label}
          {required && <span className="req">*</span>}
        </span>
        {src && src !== 'manual' && <span className="src-tag">{srcLabels[src]}</span>}
      </div>
      {children}
      {help && <div className="help">{help}</div>}

      <div className="field-actions">
        {actions.includes('ai') && src !== 'manual' && (
          <button className="primary" title="Reescrever com IA">
            <Icon.sparkle /> IA
          </button>
        )}
        {actions.includes('refresh') && <button title="Regenerar"><Icon.refresh /></button>}
        {actions.includes('copy') && <button title="Copiar"><Icon.copy /></button>}
        {actions.length > 0 && <span className="sep" />}
        <button title="Mais ações"><Icon.more /></button>
      </div>
    </div>
  );
}

function Declaro({ num, label, required, focusedId, setFocusedId, id }) {
  const [on, setOn] = useStateS2(true);
  return (
    <Field num={num} label={label} required={required} src="manual" id={id} focusedId={focusedId} setFocusedId={setFocusedId} actions={[]}>
      <div className="declaro">
        <div className="toggle">
          <button className={on ? 'on' : ''} onClick={() => setOn(true)}>Sim</button>
          <button className={!on ? 'on' : ''} onClick={() => setOn(false)}>Não</button>
        </div>
        <span className="meta">Declaração obrigatória</span>
      </div>
    </Field>
  );
}

function StepPlan({ state, onNext, onBack }) {
  const [focusedId, setFocusedId] = useStateS2(null);
  const { benef, emenda } = state;
  const meses = 36;

  return (
    <div className="main">
      <h1>Plano de trabalho pré-preenchido</h1>
      <p className="lede">Revise os campos sugeridos. Ao clicar em <Icon.sparkle /> <b>IA</b> você pode reescrever, encurtar ou adaptar cada texto. Tudo permanece no seu controle antes de enviar ao TransfereGov.</p>

      <div className="meta-strip">
        <div className="item"><div className="k">Beneficiário</div><div className="v">{benef?.name}</div></div>
        <div className="item"><div className="k">Emenda</div><div className="v mono">{emenda?.id}</div></div>
        <div className="item"><div className="k">Valor</div><div className="v">R$ {(emenda?.valor || 0).toLocaleString('pt-BR')}</div></div>
        <div className="item"><div className="k">Funcional</div><div className="v mono">31.101.{emenda?.funcional}</div></div>
      </div>

      <div className="legend">
        <span style={{ fontWeight: 500, color: 'var(--ink-2)' }}>Origem dos campos:</span>
        <span className="item"><span className="swatch api"/> API TransfereGov</span>
        <span className="item"><span className="swatch hist"/> Histórico aprovado</span>
        <span className="item"><span className="swatch ai"/> Gerado por IA</span>
        <span className="item" style={{ marginLeft: 'auto', color: 'var(--ink-4)' }}>Clique em um campo para ver ações</span>
      </div>

      {/* Section 1 */}
      <div className="card">
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">01</span> Plano de trabalho</h2>
            <p className="hint">Dados orçamentários e de prazo para execução do recurso.</p>
          </div>
          <div className="count">4 campos</div>
        </div>

        <Declaro num="1.1" label="Os recursos foram indicados no orçamento próprio do beneficiário?" required id="f11" focusedId={focusedId} setFocusedId={setFocusedId} />

        <Field num="1.2" label="Classificação orçamentária de despesa" required src="hist" id="f12" focusedId={focusedId} setFocusedId={setFocusedId}
          help="Baseado em informação do exercício anterior. Verifique compatibilidade com o orçamento vigente.">
          <div className="value-display">Programa de Trabalho: 31.101.20.608.0038.2244 — Apoio a capacitação técnica no meio rural, pesqueiro e agrícola.</div>
        </Field>

        <Declaro num="1.3" label="Declaro que os recursos não serão utilizados para despesa de pessoal e serviço da dívida" required id="f13" focusedId={focusedId} setFocusedId={setFocusedId} />

        <Field num="1.4" label="Prazo de execução (meses)" required src="hist" id="f14" focusedId={focusedId} setFocusedId={setFocusedId}
          help="Valor sugerido com base em planos aprovados anteriormente para este beneficiário.">
          <input type="number" defaultValue={meses} />
        </Field>
      </div>

      {/* Section 2 */}
      <div className="card">
        <div className="card-hd">
          <div>
            <h2><span className="section-tag">02</span> Detalhamento do executor</h2>
            <p className="hint">Quem executa, o que será executado e como os recursos serão geridos.</p>
          </div>
          <div className="count">11 campos</div>
        </div>

        <Field num="2.2" label="Executor" required src="hist" id="f22" focusedId={focusedId} setFocusedId={setFocusedId}>
          <div className="value-display">27080555000147 — SECRETARIA DE ESTADO DA AGRICULTURA, ABASTECIMENTO, AQUICULTURA E PESCA</div>
        </Field>

        <Field num="2.3" label="Objeto de execução" required src="api" id="f23" focusedId={focusedId} setFocusedId={setFocusedId}
          help="Campo pré-preenchido pelo parlamentar via SIOP. Ajustes devem ser compatíveis com o objeto original.">
          <div className="value-display">{emenda?.objeto}</div>
        </Field>

        <Field num="2.5" label="Detalhamento do objeto de execução" required src="hist" id="f25" focusedId={focusedId} setFocusedId={setFocusedId}
          help="Baseado no texto do executor em planos aprovados similares. Use IA para adaptar ao objeto específico.">
          <textarea defaultValue="O projeto prevê a capacitação técnica de aproximadamente 450 produtores rurais, pescadores artesanais e aquicultores do Espírito Santo, por meio de oficinas presenciais, visitas técnicas e material didático impresso. As atividades serão conduzidas em parceria com o Incaper nas regiões Norte, Sul e Central do estado." />
        </Field>

        <Field num="2.6" label="Finalidades" required src="ai" id="f26" focusedId={focusedId} setFocusedId={setFocusedId}>
          <textarea defaultValue="Fortalecer a assistência técnica e extensão rural; ampliar o acesso dos produtores familiares a práticas sustentáveis; promover o desenvolvimento da aquicultura e pesca artesanal capixaba." />
        </Field>

        <Field num="2.7" label="Meta 1" required src="ai" id="f27" focusedId={focusedId} setFocusedId={setFocusedId}>
          <textarea defaultValue="Realizar 24 oficinas de capacitação técnica, alcançando pelo menos 450 beneficiários diretos, com material didático e certificação, ao longo de 36 meses." />
        </Field>

        <Declaro num="2.8" label="Os recursos serão gerenciados por conta específica do executor?" required id="f28" focusedId={focusedId} setFocusedId={setFocusedId} />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
          <Field num="2.9" label="Banco do executor" required src="hist" id="f29" focusedId={focusedId} setFocusedId={setFocusedId}>
            <input type="text" defaultValue="001 — Banco do Brasil" />
          </Field>
          <Field num="2.10" label="Agência do executor" required src="hist" id="f210" focusedId={focusedId} setFocusedId={setFocusedId}>
            <input type="text" defaultValue="3823-0" />
          </Field>
        </div>
      </div>

      <div className="actionbar">
        <div className="summary">
          <b>21 campos</b> pré-preenchidos · <b>0 pendências</b>
        </div>
        <button className="btn ghost" onClick={onBack}><Icon.arrowL /> Voltar</button>
        <button className="btn primary" onClick={onNext}>Revisar e concluir <Icon.arrowR /></button>
      </div>
    </div>
  );
}

Object.assign(window, { StepPlan });

/* global React, ReactDOM, StepSelection, StepPlan, StepSubmit, Icon */
const { useState, useEffect } = React;

const TWEAKS = /*EDITMODE-BEGIN*/{
  "accent": "blue",
  "density": "comfortable",
  "badges": "line"
}/*EDITMODE-END*/;

const ACCENTS = {
  blue:  { brand: '#1f4fa8', ink: '#122e63', soft: '#e9eff9', softer: '#f4f7fc' },
  green: { brand: '#1a6847', ink: '#0e3f2a', soft: '#e4efe9', softer: '#f1f7f4' },
  amber: { brand: '#a66a12', ink: '#6a420a', soft: '#f6ecd7', softer: '#faf4e6' },
  slate: { brand: '#2a2d34', ink: '#0e1014', soft: '#e7e8ea', softer: '#f2f2f4' },
};

function applyTweaks(t) {
  const a = ACCENTS[t.accent] || ACCENTS.blue;
  document.documentElement.style.setProperty('--brand', a.brand);
  document.documentElement.style.setProperty('--brand-ink', a.ink);
  document.documentElement.style.setProperty('--brand-soft', a.soft);
  document.documentElement.style.setProperty('--brand-softer', a.softer);
  document.documentElement.setAttribute('data-density', t.density);
  document.documentElement.setAttribute('data-badges', t.badges);
}

function TopBar({ step }) {
  const steps = ['Seleção', 'Plano de trabalho', 'Envio'];
  return (
    <header className="topbar">
      <div className="brand">
        <div className="mark" aria-label="TransfereGov Assistente">
          <svg viewBox="0 0 40 40" width="24" height="24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <rect x="7" y="5" width="20" height="26" rx="2.5" fill="#fff" opacity="0.95"/>
            <rect x="11" y="11" width="10" height="1.6" rx="0.8" fill="currentColor" opacity="0.55"/>
            <rect x="11" y="15" width="12" height="1.6" rx="0.8" fill="currentColor" opacity="0.55"/>
            <rect x="11" y="19" width="7" height="1.6" rx="0.8" fill="currentColor" opacity="0.55"/>
            <circle cx="27" cy="28" r="7.5" fill="currentColor"/>
            <path d="M23.5 28h6M26.5 25l3 3-3 3" stroke="#fff" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
          </svg>
        </div>
        <div>
          <div className="title">TransfereGov <span className="accent">Assistente</span></div>
          <div className="subtitle">Plano de Trabalho Pré-preenchido · Transferências Especiais</div>
        </div>
      </div>
      <div className="spacer" />
      <div className="credit">
        <span className="credit-k">Desenvolvido por</span>
        <span className="credit-v">Tesouro Estadual · SEFAZ-ES</span>
      </div>
      <span className="chip"><span className="dot" /> Conectado à API</span>
    </header>
  );
}

function Stepper({ step, setStep }) {
  const items = [
    { t: 'Seleção', s: 'Emenda e beneficiário' },
    { t: 'Plano de trabalho', s: 'Revisar e editar campos' },
    { t: 'Envio', s: 'Resumo e confirmação' },
  ];
  return (
    <>
      <nav className="stepper-v">
        <div className="eyebrow">Novo plano</div>
        {items.map((it, i) => {
          const cls = i < step ? 'done' : i === step ? 'active' : '';
          return (
            <div key={i} className={'step ' + cls} onClick={() => i < step && setStep(i)}>
              <div className="num">{i < step ? '✓' : i + 1}</div>
              <div>
                <div className="lbl">{it.t}</div>
                <div className="sub">{it.s}</div>
              </div>
            </div>
          );
        })}
      </nav>
      <nav className="stepper-m">
        <div style={{ width: '100%' }}>
          <div className="current">
            <span className="step-name">{items[step].t}</span>
            <span className="step-count">Etapa {step + 1} de 3</span>
          </div>
          <div style={{ display: 'flex', gap: 4 }}>
            {items.map((_, i) => (
              <div key={i} className={'bar ' + (i < step ? 'done' : i === step ? 'active' : '')} />
            ))}
          </div>
        </div>
      </nav>
    </>
  );
}

function Tweaks({ tweaks, setTweaks, open }) {
  if (!open) return null;
  const update = (k, v) => setTweaks((t) => {
    const next = { ...t, [k]: v };
    applyTweaks(next);
    try {
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
    } catch (e) {}
    return next;
  });
  return (
    <div className="tweaks">
      <h3>✦ Tweaks</h3>
      <div className="tweak">
        <label>Acento</label>
        <div className="swatches">
          {Object.entries(ACCENTS).map(([k, v]) => (
            <button key={k} className={tweaks.accent === k ? 'on' : ''} style={{ background: v.brand }} onClick={() => update('accent', k)} />
          ))}
        </div>
      </div>
      <div className="tweak">
        <label>Densidade</label>
        <div className="opts">
          <button className={tweaks.density === 'comfortable' ? 'on' : ''} onClick={() => update('density', 'comfortable')}>Confortável</button>
          <button className={tweaks.density === 'compact' ? 'on' : ''} onClick={() => update('density', 'compact')}>Compacto</button>
        </div>
      </div>
      <div className="tweak">
        <label>Origem dos campos</label>
        <div className="opts">
          <button className={tweaks.badges === 'line' ? 'on' : ''} onClick={() => update('badges', 'line')}>Barra lateral</button>
          <button className={tweaks.badges === 'badge' ? 'on' : ''} onClick={() => update('badges', 'badge')}>Tag</button>
          <button className={tweaks.badges === 'tint' ? 'on' : ''} onClick={() => update('badges', 'tint')}>Tingimento</button>
        </div>
      </div>
    </div>
  );
}

function App({ startStep = 0 }) {
  const [step, setStep] = useState(startStep);
  const [state, setState] = useState({
    benef: BENEFS[0],
    emenda: EMENDAS[0],
  });
  const [tweaks, setTweaks] = useState(TWEAKS);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  useEffect(() => { applyTweaks(tweaks); }, []);

  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data?.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', onMsg);
    try { window.parent.postMessage({ type: '__edit_mode_available' }, '*'); } catch (e) {}
    return () => window.removeEventListener('message', onMsg);
  }, []);

  return (
    <div className="app">
      <TopBar step={step} />
      <div className="shell">
        <Stepper step={step} setStep={setStep} />
        {step === 0 && <StepSelection state={state} setState={setState} onNext={() => setStep(1)} />}
        {step === 1 && <StepPlan state={state} onNext={() => setStep(2)} onBack={() => setStep(0)} />}
        {step === 2 && <StepSubmit state={state} onBack={() => setStep(1)} onRestart={() => setStep(0)} />}
      </div>
      <Tweaks tweaks={tweaks} setTweaks={setTweaks} open={tweaksOpen} />
    </div>
  );
}

Object.assign(window, { App, applyTweaks, TWEAKS, ACCENTS });
